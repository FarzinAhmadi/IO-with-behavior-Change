def say_hello(name):
	print("Hello, " + name + "! Nice to meet you :)")
	return 

def ask_hru():
	print("How are you???????")